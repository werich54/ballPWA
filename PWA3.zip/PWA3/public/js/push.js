var webPush = require('web-push');
 
const vapidKeys = {
   "publicKey": "BE3F5SsIbL-AFbRjzf5-QMydn8SwAJ4k9A-9kZFO6uagf0lQt9byzLes6Xl3Z-vubxxbJwviRLCzSA8ee4G4XBU",
   "privateKey": "8ATqvnDUuTkOK0odrmDLNUJplYWUX9s7niBzFupRt_w"
};
 
 
webPush.setVapidDetails(
   "mailto:muhammadcalfin08@gmail.com",
   vapidKeys.publicKey,
   vapidKeys.privateKey
)
var pushSubscription = {
   "endpoint": "https://fcm.googleapis.com/fcm/send/fw_fPTtIrvw:APA91bFs9mxxTVI0pF-gi5CpOSO2HBROklL068tuj2k5CEy5yR0pwyGCKAhiTzn5k-gsLLmBYbB0C5GHtqC4f-hnh_XRQuU5s4s1KDEOy--HwzBgT-yJkmvIOqc_TTeID4JcrrHMMpsM",
   "keys": {
       "p256dh": "BPHEa58jqK5MgfIPGE6k1qPcH0SreqHAlPlj+ghUeFxSG4cpsBB213P4NZePDsPMod8r9lwq2fkhr290JXrSmxg=",
       "auth": "kz7O1mLBpzBvu+Qz4iIXbg=="
   }
};
var payload = 'Selamat! Aplikasi Anda sudah dapat menerima push notifikasi!';
 
var options = {
   gcmAPIKey: '469123448118',
   TTL: 60
};
webPush.sendNotification(
   pushSubscription,
   payload,
   options
);