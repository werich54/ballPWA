
// REGISTER SERVICE WORKER
if ("serviceWorker" in navigator) {
  window.addEventListener("load", function() {
    navigator.serviceWorker
      .register("/service-worker.js")
      .then(function() {
        console.log("Pendaftaran ServiceWorker berhasil");
      })
      .catch(function() {
        console.log("Pendaftaran ServiceWorker gagal");
      });
  });
} else {
  console.log("ServiceWorker belum didukung browser ini.");
}
document.addEventListener("DOMContentLoaded", function () {
  var urlParams = new URLSearchParams(window.location.search);
var isFromSaved = urlParams.get("saved");
var save = document.getElementById("save");
var hapus = document.getElementById("hapus");

if (isFromSaved) {
  save.style.display = 'none';
  hapus.style.display = 'show';
  getSavedArticleById();
  hapus.onclick = function () {
      item.then(function (article) {
          Hapus(article);
      });
  };
} else {
  hapus.style.display = 'none';
}
var item = getArticleById();

save.onclick = function () {
  item.then(function (article) {
      saveForLater(article);
  });
};
});